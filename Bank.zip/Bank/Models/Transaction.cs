﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Bank.Models
{
    public class Transaction
    {
        [Key]
        public int TransactionNo { get; set; }
        public string TransactionType { get; set; }
        public string Description { get; set; }
        [RegularExpression(@"^[0-9]+(\.[0-9]{1,2})$", ErrorMessage = "Valid Decimal number with maximum 2 decimal places.")]
        public decimal Amount { get; set; }
        public int AccountNo { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
