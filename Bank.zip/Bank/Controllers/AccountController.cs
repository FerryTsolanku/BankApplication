﻿using Bank.Data;
using Bank.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bank.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        BankDbContext dbContext = new BankDbContext();
        Transaction trans = new Transaction();

        //Validate user logins
        [HttpGet]
        public IActionResult Login(string username,string password)
        {
            var account = dbContext.BankAccounts.Where(t => t.Name == username && t.password == password).FirstOrDefault();
            if (account != null)
                return View("Index");
            else
                return View();
        }

        //access User logged in bank account
        [HttpGet]
        public IActionResult Index(int accountNo)
        {
            var account = dbContext.BankAccounts.Where(t => t.AccountNo == accountNo).ToList();
            
                return View(account);
        }

        //Get account trasaction history
        [HttpGet]
        public List<Transaction> TransactionsByAcc(int AccountNo)
        {
            var account= dbContext.Transactions.Where(t => t.AccountNo == AccountNo).OrderByDescending(t => t.CreatedDate).ToList();
            return account;
        }

        //Open account in accordance with account type, and validate the opening balance 
        // for the savings account, it must be greater or equal to R1000.00,
        //and no opening balance is required for current account.
        [HttpPost]
        public string CreateAccount(BankAccount bank)
        {
            if (bank.AccountType.ToUpper() == "SAVINGS" && bank.Balance > 1000)
            {
                trans.AccountNo = bank.AccountNo;
                trans.TransactionType = "Debit";
                trans.Description = "Opening Deposit";
                trans.CreatedDate = DateTime.Now;
                trans.Amount = bank.Balance;

                try
                {
                    dbContext.Add<BankAccount>(bank);
                    dbContext.Add<Transaction>(trans);
                    dbContext.SaveChanges();
                }
                catch (Exception ex)
                {

                }
            }
            if (bank.AccountType.ToUpper() == "SAVINGS" && bank.Balance < 1000)//make deposit if balance is less than R1000.00
            {
                Deposit(bank.AccountNo, bank.Balance);
                trans.AccountNo = bank.AccountNo;
                trans.TransactionType = "Debit";
                trans.Description = "Deposit";
                trans.CreatedDate = DateTime.Now;
                trans.Amount = bank.Balance;

                try
                {
                    dbContext.Add<Transaction>(trans);
                    dbContext.SaveChanges();
                }
                catch (Exception ex)
                {

                }
            }
            if (bank.AccountType.ToUpper() == "CURRENT")
            {
                Deposit(bank.AccountNo, bank.Balance);

                trans.AccountNo = bank.AccountNo;
                trans.TransactionType = "Debit";
                trans.Description = "Deposit";
                trans.CreatedDate = DateTime.Now;
                trans.Amount = bank.Balance;

                try
                {
                    dbContext.Add<BankAccount>(bank);
                    dbContext.Add<Transaction>(trans);
                    dbContext.SaveChanges();
                }
                catch (Exception ex)
                {

                }
            }
            
            return "Account succefully created";
        }

        //Deposit for savings and current account
        public decimal makeDeposit(int AccountNo,decimal amount)
        {
            decimal balance = 0;

            balance = Deposit(AccountNo, amount);

            trans.AccountNo = AccountNo;
            trans.TransactionType = "Debit";
            trans.Description = "Deposit";
            trans.CreatedDate = DateTime.Now;
            trans.Amount = balance;

            try
            {
                dbContext.Add<Transaction>(trans);
                dbContext.SaveChanges();
            }
            catch (Exception ex)
            {

            }

            return balance;
        }

        //withdraw money from savings account if balance is not less than R1000
        //withdraw from current account if money is not less than overdraft of R100000
        public decimal makeWithdrawal(int AccountNo,decimal amount)
        {
            decimal balance = 0;
            var accType = dbContext.BankAccounts.Where(acc => acc.AccountNo == AccountNo).Select(p => new { p.AccountType }).FirstOrDefault();
            var accBalance = dbContext.BankAccounts.Where(acc => acc.AccountNo == AccountNo).Select(p => new { p.Balance }).FirstOrDefault();

            decimal _accBalance = Convert.ToDecimal(accBalance);

            if (accType.ToString().ToUpper() == "SAVINGS" && _accBalance > 1000)//if savings account check balance if not less than 1000
            {
                balance = Withdraw(AccountNo, amount);

                trans.AccountNo = AccountNo;
                trans.TransactionType = "Credit";
                trans.Description = "Withdrawal";
                trans.CreatedDate = DateTime.Now;
                trans.Amount = balance;

                try
                {
                    dbContext.Add<Transaction>(trans);
                    dbContext.SaveChanges();
                }
                catch (Exception ex)
                {

                }
            }

            if (accType.ToString().ToUpper() == "CURRENT" && _accBalance >= -100000) //if current account check balance
            {
                _accBalance += _accBalance + 100000;
                if (_accBalance > amount)
                {
                    decimal newbalance = _accBalance - amount;

                    trans.AccountNo = AccountNo;
                    trans.TransactionType = "Credit";
                    trans.Description = "Withdrawal";
                    trans.CreatedDate = DateTime.Now;
                    trans.Amount = newbalance;
                    try
                    {
                        dbContext.Add<Transaction>(trans);
                        dbContext.SaveChanges();
                    }
                    catch (Exception ex)
                    { 

                    }
                }
            }
           
            return balance;
        }

        //Deposit amount and save new balance to database
        public decimal Deposit(int AccountNo,decimal amount)
        {
            var balance = dbContext.BankAccounts.Where(acc => acc.AccountNo == AccountNo).Select(p => new { p.Balance }).FirstOrDefault();
            decimal newBalance = Convert.ToDecimal(balance);
            newBalance = newBalance + amount;

            var acc = new BankAccount() { Balance = newBalance };

            try
            {
                dbContext.BankAccounts.Attach(acc);
                dbContext.Entry(acc).Property(x => x.Balance).IsModified = true;
                dbContext.SaveChanges();
            }
            catch (Exception ex)
            {

            }

            return newBalance;
        }

        //Withdraw amount and save new balance to database
        public decimal Withdraw(int AccountNo, decimal amount)
        {
            var balance = dbContext.BankAccounts.Where(acc => acc.AccountNo == AccountNo).Select(p => new { p.Balance }).FirstOrDefault();
            decimal newBalance = Convert.ToDecimal(balance);
            newBalance = newBalance - amount;

            var acc = new BankAccount() { Balance = newBalance };

            try
            {
                dbContext.BankAccounts.Attach(acc);
                dbContext.Entry(acc).Property(x => x.Balance).IsModified = true;
                dbContext.SaveChanges();
            }
            catch (Exception ex)
            {

            }

            return newBalance;
        }

        //Transfer money from savings to current account then less amount transfferd from savings account,
        //then add transffered amount to balance and save new balance, and vice versa.
        public void Transfer(int AccountNo, decimal amount)
        {
            var account = dbContext.BankAccounts.Where(acc => acc.AccountNo == AccountNo).FirstOrDefault();

            if (account.AccountType.ToString().ToUpper() == "SAVINGS")
            {
                account.AccountNo = AccountNo;
                account.AccountType = "Current";
                account.Name = account.Name;
                account.CreatedDate = DateTime.Now;
                decimal oldBalance = account.Balance - amount;
                account.Balance = account.Balance + amount;
                
                var acc = new BankAccount() { Balance = oldBalance };

                try
                {
                    dbContext.BankAccounts.Attach(acc);
                    dbContext.Entry(acc).Property(x => x.Balance).IsModified = true;

                    dbContext.Add<BankAccount>(account);
                    dbContext.SaveChanges();
                }
                catch (Exception ex)
                {

                }
            }
            if (account.AccountType.ToString().ToUpper() == "CURRENT")
            {
                account.AccountNo = AccountNo;
                account.AccountType = "SAVINGS";
                account.Name = account.Name;
                account.CreatedDate = DateTime.Now;
                decimal oldBalance = account.Balance - amount;
                account.Balance = account.Balance + amount;

                var acc = new BankAccount() { Balance = oldBalance };

                try
                {
                    dbContext.BankAccounts.Attach(acc);
                    dbContext.Entry(acc).Property(x => x.Balance).IsModified = true;

                    dbContext.Add<BankAccount>(account);
                    dbContext.SaveChanges();
                }
                catch (Exception ex)
                {

                }
            }
            
        }
    }
}
